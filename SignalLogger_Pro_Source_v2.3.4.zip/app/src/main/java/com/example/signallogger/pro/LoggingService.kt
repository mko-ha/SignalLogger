package com.example.signallogger.pro

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.os.*
import android.provider.Settings
import android.net.Uri
import android.telephony.*
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap

class LoggingService : Service() {

    companion object {
        // Shared with MainActivity when it creates a stable CSV snapshot.
        // This prevents a share operation from copying a half-written row.
        @JvmField
        val FILE_LOCK = Any()
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var logFile: File
    private var publicUri: Uri? = null
    private var intervalMs = 60_000L
    private var lastLocation: Location? = null
    private var rowCount = 0L
    private var wakeLock: PowerManager.WakeLock? = null

    private data class SubState(
        var serviceState: ServiceState? = null,
        var signalStrength: SignalStrength? = null,
        var displayInfo: TelephonyDisplayInfo? = null,
        var cellInfo: List<CellInfo> = emptyList(),
        var lastSignalUpdateElapsedMs: Long = 0L,
        var lastCellUpdateElapsedMs: Long = 0L,
        var lastServiceName: String = "UNKNOWN",
        var lastNetworkName: String = "UNKNOWN",
        var lastCellKey: String = ""
    )

    private data class OutageState(
        val slot: Int,
        val carrier: String,
        val startWallMs: Long,
        var startLat: Double? = null,
        var startLon: Double? = null,
        var distanceMeters: Float = 0f,
        var lastLocation: Location? = null
    )

    private val states = ConcurrentHashMap<Int, SubState>()
    private val outages = ConcurrentHashMap<Int, OutageState>()
    private val callbacks = ConcurrentHashMap<Int, TelephonyCallback>()
    private val telephonyManagers = ConcurrentHashMap<Int, TelephonyManager>()

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val best = result.lastLocation ?: return
            lastLocation = best
            persistLocation(best)
            updateOutageDistances(best)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        fused = LocationServices.getFusedLocationProviderClient(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intervalMs = intent?.getLongExtra("intervalMs", 60_000L) ?: 60_000L
        prefs().edit().putBoolean("running", true).apply()
        if (!::logFile.isInitialized) {
            // Android can recreate a START_STICKY service with a null Intent.
            // In that case continue the same CSV instead of silently starting
            // a second file and resetting the visible counter.
            val restored = if (intent == null) restoreCurrentLogFile() else false
            if (!restored) createLogFile(intent?.getStringExtra("sessionName"))
        }

        startForeground(1001, buildNotification(notificationText()))
        handler.removeCallbacks(notificationTicker)
        handler.post(notificationTicker)
        acquireWakeLock()
        startLocationUpdates()
        startTelephonyWatch()

        handler.removeCallbacks(periodic)
        handler.post(periodic)
        return START_STICKY
    }

    private fun createLogFile(sessionName: String?) {
        val dir = getExternalFilesDir("logs") ?: filesDir
        dir.mkdirs()
        val safe = sessionName.orEmpty()
            .trim()
            .replace(Regex("[^A-Za-z0-9_\\-ぁ-んァ-ヶ一-龠]"), "_")
            .take(30)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = if (safe.isBlank()) "signal_$stamp.csv" else "signal_${stamp}_$safe.csv"
        logFile = File(dir, name)
        val header =
            "timestamp,reason,latitude,longitude,accuracy_m,location_age_ms,provider,speed_mps,bearing_deg," +
            "sim_slot,subscription_id,is_embedded,carrier,mcc,mnc,service_state,network_type,signal_source,signal_age_ms,cell_age_ms,dbm," +
            "rsrp,rsrq,rssnr,ss_rsrp,ss_rsrq,ss_sinr,cell_id,tac_lac,pci,arfcn,roaming,data_state," +
            "battery_pct,charging,power_save,airplane_mode,outage_start_time,outage_start_lat,outage_start_lon,outage_elapsed_ms,outage_distance_m\n"
        synchronized(FILE_LOCK) { logFile.writeText(header) }

        publicUri = PublicLogStore.create(this, name, "text/csv")
        publicUri?.let { PublicLogStore.writeText(this, it, header, false) }

        rowCount = 0L
        val clearEditor = prefs().edit()
        for (slot in 0..1) {
            clearEditor.remove("outage_start_ms_$slot")
                .remove("outage_start_lat_$slot")
                .remove("outage_start_lon_$slot")
                .remove("outage_distance_m_$slot")
        }
        clearEditor.apply()
        prefs().edit()
            .putString("current_file", logFile.absolutePath)
            .putString("public_file_uri", publicUri?.toString())
            .putString("public_file_name", name)
            .putLong("row_count", rowCount)
            .apply()
    }

    private fun restoreCurrentLogFile(): Boolean {
        val path = prefs().getString("current_file", null) ?: return false
        val candidate = File(path)
        if (!candidate.exists() || !candidate.isFile) return false
        logFile = candidate
        rowCount = synchronized(FILE_LOCK) { countCsvRows(candidate) }
        publicUri = prefs().getString("public_file_uri", null)?.let { runCatching { Uri.parse(it) }.getOrNull() }
        if (publicUri == null) {
            publicUri = PublicLogStore.create(this, candidate.name, "text/csv")
            publicUri?.let { PublicLogStore.copyLocalFile(this, it, candidate) }
            prefs().edit()
                .putString("public_file_uri", publicUri?.toString())
                .putString("public_file_name", candidate.name)
                .apply()
        }
        prefs().edit().putLong("row_count", rowCount).apply()
        return true
    }

    private fun countCsvRows(file: File): Long {
        if (!file.exists() || file.length() == 0L) return 0L
        return file.bufferedReader().useLines { lines ->
            (lines.count() - 1).coerceAtLeast(0).toLong()
        }
    }

    private val periodic = object : Runnable {
        override fun run() {
            capture("PERIODIC")
            handler.postDelayed(this, intervalMs)
        }
    }

    private fun capture(reason: String) {
        if (!hasLocationPermission()) {
            writeTelephonyRowsFresh(lastLocation, reason)
            return
        }

        val loc = lastLocation
        val stale = loc == null || (SystemClock.elapsedRealtimeNanos() - loc.elapsedRealtimeNanos) / 1_000_000 > 20_000
        if (!stale) {
            writeTelephonyRowsFresh(loc, reason)
            return
        }

        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { fresh ->
                if (fresh != null) lastLocation = fresh
                writeTelephonyRowsFresh(lastLocation, reason)
            }
            .addOnFailureListener {
                writeTelephonyRowsFresh(lastLocation, reason)
            }
    }

    private fun startLocationUpdates() {
        if (!hasLocationPermission()) return
        val updateMs = (intervalMs / 2).coerceIn(3_000L, 15_000L)
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, updateMs)
            .setMinUpdateIntervalMillis(2_000L)
            .setMinUpdateDistanceMeters(0f)
            .build()
        fused.removeLocationUpdates(locationCallback)
        fused.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
    }

    private fun startTelephonyWatch() {
        if (!hasPhonePermission()) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return

        val sm = getSystemService(SubscriptionManager::class.java)
        val tmBase = getSystemService(TelephonyManager::class.java)
        val subs = try { sm.activeSubscriptionInfoList ?: emptyList() } catch (_: SecurityException) { emptyList() }

        for (sub in subs) {
            if (callbacks.containsKey(sub.subscriptionId)) continue

            val subId = sub.subscriptionId
            val tm = tmBase.createForSubscriptionId(subId)
            telephonyManagers[subId] = tm
            val state = states.getOrPut(subId) { SubState() }

            val cb = object : TelephonyCallback(),
                TelephonyCallback.ServiceStateListener,
                TelephonyCallback.SignalStrengthsListener,
                TelephonyCallback.DisplayInfoListener,
                TelephonyCallback.CellInfoListener,
                TelephonyCallback.DataConnectionStateListener {

                override fun onServiceStateChanged(newState: ServiceState) {
                    val oldName = state.lastServiceName
                    state.serviceState = newState
                    val newName = serviceStateName(newState.state)
                    state.lastServiceName = newName
                    val carrier = sub.carrierName?.toString()?.ifBlank { "SIM${sub.simSlotIndex + 1}" } ?: "SIM${sub.simSlotIndex + 1}"
                    if (oldName != "UNKNOWN" && oldName != newName) {
                        val reason = when {
                            oldName == "IN_SERVICE" && newName != "IN_SERVICE" -> {
                                startOutage(subId, sub.simSlotIndex, carrier)
                                "SERVICE_LOST"
                            }
                            oldName != "IN_SERVICE" && newName == "IN_SERVICE" -> {
                                handler.postDelayed({ clearOutage(subId, sub.simSlotIndex) }, 2200L)
                                "SERVICE_RESTORED"
                            }
                            else -> "SERVICE_STATE_CHANGED"
                        }
                        capture(reason)
                    }
                    updateNotificationNow()
                }

                override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
                    state.signalStrength = signalStrength
                    state.lastSignalUpdateElapsedMs = SystemClock.elapsedRealtime()
                }

                override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) {
                    state.displayInfo = telephonyDisplayInfo
                    val tmNow = telephonyManagers[subId]
                    val newNetwork = effectiveNetworkName(tmNow, state)
                    val oldNetwork = state.lastNetworkName
                    state.lastNetworkName = newNetwork
                    if (oldNetwork != "UNKNOWN" && oldNetwork != newNetwork) {
                        capture("NETWORK_CHANGED")
                    }
                }

                override fun onCellInfoChanged(cellInfo: MutableList<CellInfo>) {
                    state.cellInfo = cellInfo
                    state.lastCellUpdateElapsedMs = SystemClock.elapsedRealtime()
                    val newKey = registeredCellKey(cellInfo)
                    val oldKey = state.lastCellKey
                    state.lastCellKey = newKey
                    if (oldKey.isNotBlank() && newKey.isNotBlank() && oldKey != newKey) {
                        capture("CELL_CHANGED")
                    }
                }

                override fun onDataConnectionStateChanged(dataState: Int, networkType: Int) {
                    // The current value is read when a row is written.
                }
            }

            try {
                tm.registerTelephonyCallback(mainExecutor, cb)
                callbacks[subId] = cb
                seedState(tm, state)
                val initialCarrier = sub.carrierName?.toString()?.ifBlank { "SIM${sub.simSlotIndex + 1}" } ?: "SIM${sub.simSlotIndex + 1}"
                if (state.lastServiceName != "IN_SERVICE") startOutage(subId, sub.simSlotIndex, initialCarrier)
                requestFreshCellInfo(tm, state)
            } catch (_: Exception) {
            }
        }
    }

    private fun seedState(tm: TelephonyManager, state: SubState) {
        try { state.serviceState = tm.serviceState } catch (_: Exception) {}
        try {
            val cells = tm.allCellInfo ?: emptyList()
            if (cells.isNotEmpty()) {
                state.cellInfo = cells
                state.lastCellUpdateElapsedMs = SystemClock.elapsedRealtime()
            }
        } catch (_: Exception) {}
        state.lastServiceName = serviceStateName(state.serviceState?.state ?: ServiceState.STATE_OUT_OF_SERVICE)
        state.lastNetworkName = effectiveNetworkName(tm, state)
        state.lastCellKey = registeredCellKey(state.cellInfo)
    }

    private fun requestFreshCellInfo(
        tm: TelephonyManager,
        state: SubState,
        onComplete: (() -> Unit)? = null
    ) {
        if (!hasLocationPermission()) {
            onComplete?.invoke()
            return
        }
        try {
            tm.requestCellInfoUpdate(mainExecutor, object : TelephonyManager.CellInfoCallback() {
                override fun onCellInfo(cellInfo: MutableList<CellInfo>) {
                    if (cellInfo.isNotEmpty()) {
                        state.cellInfo = cellInfo
                        state.lastCellUpdateElapsedMs = SystemClock.elapsedRealtime()
                    }
                    onComplete?.invoke()
                }

                override fun onError(errorCode: Int, detail: Throwable?) {
                    onComplete?.invoke()
                }
            })
        } catch (_: Exception) {
            onComplete?.invoke()
        }
    }

    /**
     * Ask every active subscription for a fresh CellInfo snapshot and wait briefly
     * before writing. This avoids repeatedly writing a cached SignalStrength value
     * on secondary/eSIM subscriptions when the modem does not dispatch callbacks
     * at the same cadence as our CSV interval.
     */
    private fun writeTelephonyRowsFresh(location: Location?, reason: String) {
        if (!hasPhonePermission() || Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            writeTelephonyRows(location, reason)
            return
        }

        val sm = getSystemService(SubscriptionManager::class.java)
        val tmBase = getSystemService(TelephonyManager::class.java)
        val subs = try { sm.activeSubscriptionInfoList ?: emptyList() } catch (_: SecurityException) { emptyList() }
        if (subs.isEmpty()) {
            writeTelephonyRows(location, reason)
            return
        }

        var remaining = subs.size
        var finished = false
        val timeout = Runnable {
            if (!finished) {
                finished = true
                writeTelephonyRows(location, reason)
            }
        }
        handler.postDelayed(timeout, 1500L)

        for (sub in subs) {
            val tm = telephonyManagers[sub.subscriptionId] ?: tmBase.createForSubscriptionId(sub.subscriptionId).also {
                telephonyManagers[sub.subscriptionId] = it
            }
            val st = states.getOrPut(sub.subscriptionId) { SubState() }
            requestFreshCellInfo(tm, st) {
                remaining--
                if (remaining <= 0 && !finished) {
                    finished = true
                    handler.removeCallbacks(timeout)
                    writeTelephonyRows(location, reason)
                }
            }
        }
    }

    private fun writeTelephonyRows(location: Location?, reason: String) {
        if (!hasPhonePermission() || !::logFile.isInitialized) return

        val sm = getSystemService(SubscriptionManager::class.java)
        val tmBase = getSystemService(TelephonyManager::class.java)
        val subs = try { sm.activeSubscriptionInfoList ?: emptyList() } catch (_: SecurityException) { emptyList() }
        val timestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(Date())
        val battery = batteryInfo()
        val powerSave = getSystemService(PowerManager::class.java).isPowerSaveMode
        val airplane = try { Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (_: Exception) { false }

        for (sub in subs) {
            val tm = telephonyManagers[sub.subscriptionId] ?: tmBase.createForSubscriptionId(sub.subscriptionId)
            telephonyManagers[sub.subscriptionId] = tm
            val st = states.getOrPut(sub.subscriptionId) { SubState() }

            val svc = st.serviceState ?: try { tm.serviceState } catch (_: Exception) { null }
            val serviceName = if (airplane) "POWER_OFF" else serviceStateName(svc?.state ?: ServiceState.STATE_OUT_OF_SERVICE)
            val network = effectiveNetworkName(tm, st)

            val cells = st.cellInfo.ifEmpty {
                try { tm.allCellInfo ?: emptyList() } catch (_: Exception) { emptyList() }
            }
            if (cells.isNotEmpty()) st.cellInfo = cells
            val registered = cells.firstOrNull { it.isRegistered }

            val metrics = signalMetrics(st.signalStrength, registered)
            val cell = cellMetrics(registered)
            val nowElapsed = SystemClock.elapsedRealtime()
            val signalAgeMs = if (st.lastSignalUpdateElapsedMs > 0L) (nowElapsed - st.lastSignalUpdateElapsedMs).coerceAtLeast(0L).toString() else ""
            val cellAgeMs = if (st.lastCellUpdateElapsedMs > 0L) (nowElapsed - st.lastCellUpdateElapsedMs).coerceAtLeast(0L).toString() else ""
            val signalSource = if (registered != null) "CELL_INFO" else if (st.signalStrength != null) "SIGNAL_CALLBACK" else "NONE"
            val carrier = sub.carrierName?.toString() ?: try { tm.networkOperatorName } catch (_: Exception) { "" }
            val dataState = try { dataStateName(tm.dataState) } catch (_: Exception) { "UNKNOWN" }
            val roaming = try { tm.isNetworkRoaming } catch (_: Exception) { false }

            val locationAge = location?.let {
                ((SystemClock.elapsedRealtimeNanos() - it.elapsedRealtimeNanos) / 1_000_000).coerceAtLeast(0)
            }
            val outage = outages[sub.subscriptionId]
            val outageElapsed = outage?.let { (System.currentTimeMillis() - it.startWallMs).coerceAtLeast(0L) }
            val outageStartText = outage?.let { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(Date(it.startWallMs)) }.orEmpty()

            val row = listOf(
                timestamp,
                reason,
                location?.latitude?.toString().orEmpty(),
                location?.longitude?.toString().orEmpty(),
                location?.accuracy?.toString().orEmpty(),
                locationAge?.toString().orEmpty(),
                location?.provider.orEmpty(),
                if (location?.hasSpeed() == true) location.speed.toString() else "",
                if (location?.hasBearing() == true) location.bearing.toString() else "",
                sub.simSlotIndex.toString(),
                sub.subscriptionId.toString(),
                sub.isEmbedded.toString(),
                carrier,
                sub.mccString.orEmpty(),
                sub.mncString.orEmpty(),
                serviceName,
                network,
                signalSource,
                signalAgeMs,
                cellAgeMs,
                metrics.dbm,
                metrics.rsrp,
                metrics.rsrq,
                metrics.rssnr,
                metrics.ssRsrp,
                metrics.ssRsrq,
                metrics.ssSinr,
                cell.cellId,
                cell.tacLac,
                cell.pci,
                cell.arfcn,
                roaming.toString(),
                dataState,
                battery.first.toString(),
                battery.second.toString(),
                powerSave.toString(),
                airplane.toString(),
                outageStartText,
                outage?.startLat?.toString().orEmpty(),
                outage?.startLon?.toString().orEmpty(),
                outageElapsed?.toString().orEmpty(),
                outage?.distanceMeters?.toString().orEmpty()
            ).joinToString(",") { csvField(it) } + "\n"

            val persisted = try {
                synchronized(FILE_LOCK) {
                    logFile.appendText(row)
                    publicUri?.let { uri -> PublicLogStore.writeText(this, uri, row, true) }
                }
                true
            } catch (_: Exception) {
                false
            }
            if (!persisted) continue

            rowCount++
            prefs().edit()
                .putLong("row_count", rowCount)
                .putString("sim_carrier_${sub.simSlotIndex}", carrier.ifBlank { "SIM${sub.simSlotIndex + 1}" })
                .putString("sim_service_${sub.simSlotIndex}", serviceName)
                .putString("sim_network_${sub.simSlotIndex}", network)
                .putString("sim_dbm_${sub.simSlotIndex}", if (serviceName == "IN_SERVICE") metrics.dbm else "")
                .apply()
        }

        prefs().edit().putLong("last_write", System.currentTimeMillis()).apply()
        updateNotificationNow()
    }

    private data class SignalMetrics(
        val dbm: String = "",
        val rsrp: String = "",
        val rsrq: String = "",
        val rssnr: String = "",
        val ssRsrp: String = "",
        val ssRsrq: String = "",
        val ssSinr: String = ""
    )

    private fun signalMetrics(signal: SignalStrength?, registered: CellInfo?): SignalMetrics {
        // requestCellInfoUpdate() is explicitly refreshed before each CSV write.
        // Prefer its registered-cell measurements over a possibly cached callback.
        try {
            when (registered) {
                is CellInfoLte -> {
                    val cs = registered.cellSignalStrength
                    return SignalMetrics(
                        dbm = valid(cs.dbm) ?: "",
                        rsrp = valid(cs.rsrp) ?: "",
                        rsrq = valid(cs.rsrq) ?: "",
                        rssnr = valid(cs.rssnr) ?: ""
                    )
                }
                is CellInfoNr -> {
                    val cs = registered.cellSignalStrength as? CellSignalStrengthNr
                    return SignalMetrics(
                        dbm = valid(cs?.dbm) ?: "",
                        ssRsrp = valid(cs?.ssRsrp) ?: "",
                        ssRsrq = valid(cs?.ssRsrq) ?: "",
                        ssSinr = valid(cs?.ssSinr) ?: ""
                    )
                }
                is CellInfoWcdma -> return SignalMetrics(dbm = valid(registered.cellSignalStrength.dbm) ?: "")
                is CellInfoGsm -> return SignalMetrics(dbm = valid(registered.cellSignalStrength.dbm) ?: "")
                is CellInfoCdma -> return SignalMetrics(dbm = valid(registered.cellSignalStrength.dbm) ?: "")
            }
        } catch (_: Exception) {
            // Fall back to TelephonyCallback snapshot below.
        }

        val strengths = try { signal?.cellSignalStrengths ?: emptyList() } catch (_: Exception) { emptyList() }
        val preferred = strengths.maxByOrNull { it.level }
        val dbm = valid(preferred?.dbm) ?: ""

        return when (preferred) {
            is CellSignalStrengthLte -> SignalMetrics(
                dbm = dbm,
                rsrp = valid(preferred.rsrp) ?: "",
                rsrq = valid(preferred.rsrq) ?: "",
                rssnr = valid(preferred.rssnr) ?: ""
            )
            is CellSignalStrengthNr -> SignalMetrics(
                dbm = dbm,
                ssRsrp = valid(preferred.ssRsrp) ?: "",
                ssRsrq = valid(preferred.ssRsrq) ?: "",
                ssSinr = valid(preferred.ssSinr) ?: ""
            )
            else -> SignalMetrics(dbm = dbm)
        }
    }

    private fun signalDbmFromCell(info: CellInfo?): Int? = try {
        when (info) {
            is CellInfoLte -> info.cellSignalStrength.dbm
            is CellInfoNr -> info.cellSignalStrength.dbm
            is CellInfoWcdma -> info.cellSignalStrength.dbm
            is CellInfoGsm -> info.cellSignalStrength.dbm
            is CellInfoCdma -> info.cellSignalStrength.dbm
            else -> null
        }
    } catch (_: Exception) { null }

    private fun valid(value: Int?): String? {
        if (value == null || value == Int.MAX_VALUE || value == CellInfo.UNAVAILABLE) return null
        return value.toString()
    }

    private data class CellMetrics(
        val cellId: String = "",
        val tacLac: String = "",
        val pci: String = "",
        val arfcn: String = ""
    )

    private fun cellMetrics(info: CellInfo?): CellMetrics = try {
        when (info) {
            is CellInfoLte -> {
                val id = info.cellIdentity
                CellMetrics(validId(id.ci), validId(id.tac), validId(id.pci), validId(id.earfcn))
            }
            is CellInfoNr -> {
                val id = info.cellIdentity as CellIdentityNr
                CellMetrics(validLongId(id.nci), validId(id.tac), validId(id.pci), validId(id.nrarfcn))
            }
            is CellInfoWcdma -> {
                val id = info.cellIdentity
                CellMetrics(validId(id.cid), validId(id.lac), validId(id.psc), validId(id.uarfcn))
            }
            is CellInfoGsm -> {
                val id = info.cellIdentity
                CellMetrics(validId(id.cid), validId(id.lac), validId(id.bsic), validId(id.arfcn))
            }
            is CellInfoCdma -> {
                val id = info.cellIdentity
                CellMetrics(validId(id.basestationId), validId(id.networkId), "", "")
            }
            else -> CellMetrics()
        }
    } catch (_: Exception) { CellMetrics() }

    private fun validId(v: Int): String =
        if (v == Int.MAX_VALUE || v == CellInfo.UNAVAILABLE || v < 0) "" else v.toString()

    private fun validLongId(v: Long): String =
        if (v == Long.MAX_VALUE || v < 0L) "" else v.toString()

    private fun registeredCellKey(cells: List<CellInfo>): String {
        val c = cells.firstOrNull { it.isRegistered } ?: return ""
        val m = cellMetrics(c)
        return "${c.javaClass.simpleName}:${m.cellId}:${m.tacLac}:${m.pci}:${m.arfcn}"
    }

    private fun effectiveNetworkName(tm: TelephonyManager?, state: SubState): String {
        val di = state.displayInfo
        if (di != null) {
            when (di.overrideNetworkType) {
                TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA,
                TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_ADVANCED -> return "5G_NR_NSA"
            }
            if (di.networkType != TelephonyManager.NETWORK_TYPE_UNKNOWN) {
                return networkTypeName(di.networkType)
            }
        }

        if (tm != null) {
            val data = try { tm.dataNetworkType } catch (_: Exception) { TelephonyManager.NETWORK_TYPE_UNKNOWN }
            if (data != TelephonyManager.NETWORK_TYPE_UNKNOWN) return networkTypeName(data)
            val voice = try { tm.voiceNetworkType } catch (_: Exception) { TelephonyManager.NETWORK_TYPE_UNKNOWN }
            if (voice != TelephonyManager.NETWORK_TYPE_UNKNOWN) return networkTypeName(voice)
        }

        val registered = state.cellInfo.firstOrNull { it.isRegistered }
        return when (registered) {
            is CellInfoNr -> "5G_NR"
            is CellInfoLte -> "4G_LTE"
            is CellInfoWcdma -> "3G_WCDMA"
            is CellInfoGsm -> "2G_GSM"
            is CellInfoCdma -> "CDMA"
            else -> "UNKNOWN"
        }
    }

    private fun networkTypeName(type: Int): String = when (type) {
        TelephonyManager.NETWORK_TYPE_NR -> "5G_NR"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G_LTE"
        TelephonyManager.NETWORK_TYPE_IWLAN -> "IWLAN"
        TelephonyManager.NETWORK_TYPE_HSPAP -> "3G_HSPA+"
        TelephonyManager.NETWORK_TYPE_HSPA,
        TelephonyManager.NETWORK_TYPE_HSDPA,
        TelephonyManager.NETWORK_TYPE_HSUPA -> "3G_HSPA"
        TelephonyManager.NETWORK_TYPE_UMTS -> "3G_UMTS"
        TelephonyManager.NETWORK_TYPE_EDGE -> "2G_EDGE"
        TelephonyManager.NETWORK_TYPE_GPRS -> "2G_GPRS"
        TelephonyManager.NETWORK_TYPE_GSM -> "2G_GSM"
        TelephonyManager.NETWORK_TYPE_CDMA,
        TelephonyManager.NETWORK_TYPE_1xRTT,
        TelephonyManager.NETWORK_TYPE_EVDO_0,
        TelephonyManager.NETWORK_TYPE_EVDO_A,
        TelephonyManager.NETWORK_TYPE_EVDO_B -> "CDMA"
        TelephonyManager.NETWORK_TYPE_UNKNOWN -> "UNKNOWN"
        else -> "TYPE_$type"
    }

    private fun serviceStateName(state: Int): String = when (state) {
        ServiceState.STATE_IN_SERVICE -> "IN_SERVICE"
        ServiceState.STATE_OUT_OF_SERVICE -> "OUT_OF_SERVICE"
        ServiceState.STATE_EMERGENCY_ONLY -> "EMERGENCY_ONLY"
        ServiceState.STATE_POWER_OFF -> "POWER_OFF"
        else -> "UNKNOWN"
    }

    private fun dataStateName(state: Int): String = when (state) {
        TelephonyManager.DATA_CONNECTED -> "CONNECTED"
        TelephonyManager.DATA_CONNECTING -> "CONNECTING"
        TelephonyManager.DATA_DISCONNECTED -> "DISCONNECTED"
        TelephonyManager.DATA_SUSPENDED -> "SUSPENDED"
        TelephonyManager.DATA_DISCONNECTING -> "DISCONNECTING"
        TelephonyManager.DATA_HANDOVER_IN_PROGRESS -> "HANDOVER"
        else -> "UNKNOWN"
    }

    private fun batteryInfo(): Pair<Int, Boolean> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return pct to charging
    }

    private fun hasLocationPermission(): Boolean =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun hasPhonePermission(): Boolean =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun csvField(v: String): String =
        if (v.contains(',') || v.contains('"') || v.contains('\n')) "\"${v.replace("\"", "\"\"")}\"" else v

    private fun prefs() = getSharedPreferences("logger", Context.MODE_PRIVATE)

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:SignalLogger").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun intervalLabel(ms: Long): String = when (ms) {
        10_000L -> "10秒"
        30_000L -> "30秒"
        60_000L -> "1分"
        120_000L -> "2分"
        300_000L -> "5分"
        600_000L -> "10分"
        else -> "${ms / 1000}秒"
    }

    private val notificationTicker = object : Runnable {
        override fun run() {
            if (prefs().getBoolean("running", false)) {
                updateNotificationNow()
                handler.postDelayed(this, 5000L)
            }
        }
    }

    private fun persistLocation(location: Location) {
        prefs().edit()
            .putString("current_lat", location.latitude.toString())
            .putString("current_lon", location.longitude.toString())
            .putString("current_accuracy", location.accuracy.toString())
            .putLong("last_fix_time_ms", location.time.takeIf { it > 0 } ?: System.currentTimeMillis())
            .apply()
    }

    private fun startOutage(subId: Int, slot: Int, carrier: String) {
        if (outages.containsKey(subId)) return
        val loc = lastLocation
        val savedStart = prefs().getLong("outage_start_ms_$slot", 0L)
        val savedLat = prefs().getString("outage_start_lat_$slot", null)?.toDoubleOrNull()
        val savedLon = prefs().getString("outage_start_lon_$slot", null)?.toDoubleOrNull()
        val savedDistance = prefs().getFloat("outage_distance_m_$slot", 0f)
        val state = OutageState(
            slot = slot,
            carrier = carrier,
            startWallMs = savedStart.takeIf { it > 0L } ?: System.currentTimeMillis(),
            startLat = savedLat ?: loc?.latitude,
            startLon = savedLon ?: loc?.longitude,
            distanceMeters = savedDistance,
            lastLocation = loc?.let { Location(it) }
        )
        outages[subId] = state
        persistOutage(state)
    }

    private fun clearOutage(subId: Int, slot: Int) {
        outages.remove(subId)
        prefs().edit()
            .remove("outage_start_ms_$slot")
            .remove("outage_start_lat_$slot")
            .remove("outage_start_lon_$slot")
            .remove("outage_distance_m_$slot")
            .apply()
        updateNotificationNow()
    }

    private fun updateOutageDistances(location: Location) {
        for (state in outages.values) {
            if (state.startLat == null || state.startLon == null) {
                state.startLat = location.latitude
                state.startLon = location.longitude
                state.lastLocation = Location(location)
                persistOutage(state)
                continue
            }
            val previous = state.lastLocation
            if (previous != null) {
                val segment = previous.distanceTo(location)
                val accuracyOk = previous.accuracy <= 200f && location.accuracy <= 200f
                if (accuracyOk && segment in 0f..5000f) state.distanceMeters += segment
            }
            state.lastLocation = Location(location)
            persistOutage(state)
        }
    }

    private fun persistOutage(state: OutageState) {
        val e = prefs().edit()
            .putLong("outage_start_ms_${state.slot}", state.startWallMs)
            .putFloat("outage_distance_m_${state.slot}", state.distanceMeters)
        state.startLat?.let { e.putString("outage_start_lat_${state.slot}", it.toString()) }
        state.startLon?.let { e.putString("outage_start_lon_${state.slot}", it.toString()) }
        e.apply()
    }

    private fun formatDuration(ms: Long): String {
        val t = ms / 1000
        val h = t / 3600
        val m = (t % 3600) / 60
        val sec = t % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d分%02d秒".format(m, sec)
    }

    private fun formatDistance(m: Float): String = if (m >= 1000f) "%.1fkm".format(m / 1000f) else "%.0fm".format(m)

    private fun notificationText(): String {
        val p = prefs()
        val lines = mutableListOf<String>()
        for (slot in 0..1) {
            val carrier = p.getString("sim_carrier_$slot", null) ?: continue
            val service = p.getString("sim_service_$slot", "UNKNOWN") ?: "UNKNOWN"
            val network = p.getString("sim_network_$slot", "UNKNOWN") ?: "UNKNOWN"
            val dbm = p.getString("sim_dbm_$slot", "") ?: ""
            val start = p.getLong("outage_start_ms_$slot", 0L)
            val dist = p.getFloat("outage_distance_m_$slot", 0f)
            if (service != "IN_SERVICE" && start > 0L) {
                lines += "$carrier：圏外 ${formatDuration((System.currentTimeMillis() - start).coerceAtLeast(0L))} / ${formatDistance(dist)}"
            } else {
                lines += "$carrier：圏内 $network" + if (dbm.isNotBlank()) " / $dbm dBm" else ""
            }
        }
        return if (lines.isEmpty()) "SIM情報を取得中" else lines.joinToString("\n")
    }

    private fun updateNotificationNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(1001, buildNotification(notificationText()))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("logging", "電波記録", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, "logging")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("SignalLogger Pro — 記録中")
            .setContentText(text.lineSequence().firstOrNull() ?: "記録中")
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { fused.removeLocationUpdates(locationCallback) } catch (_: Exception) {}

        for ((subId, cb) in callbacks) {
            try { telephonyManagers[subId]?.unregisterTelephonyCallback(cb) } catch (_: Exception) {}
        }
        callbacks.clear()
        telephonyManagers.clear()

        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}

        prefs().edit().putBoolean("running", false).apply()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
