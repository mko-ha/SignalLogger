package com.example.signallogger.pro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var status: TextView
    private lateinit var fileText: TextView
    private lateinit var currentTimeText: TextView
    private lateinit var locationText: TextView
    private lateinit var sim0Text: TextView
    private lateinit var sim1Text: TextView
    private lateinit var sim0Map: Button
    private lateinit var sim1Map: Button
    private lateinit var sessionName: EditText
    private val uiHandler = Handler(Looper.getMainLooper())

    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshStatus()
            uiHandler.postDelayed(this, 1000)
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val phone = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        if (fine && phone) startLogger()
        else status.text = "位置情報と電話の権限が必要です"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinner = findViewById(R.id.intervalSpinner)
        status = findViewById(R.id.statusText)
        fileText = findViewById(R.id.fileText)
        currentTimeText = findViewById(R.id.currentTimeText)
        locationText = findViewById(R.id.locationText)
        sim0Text = findViewById(R.id.sim0Text)
        sim1Text = findViewById(R.id.sim1Text)
        sim0Map = findViewById(R.id.sim0MapButton)
        sim1Map = findViewById(R.id.sim1MapButton)
        sessionName = findViewById(R.id.sessionName)

        val labels = listOf("10秒", "30秒", "1分", "2分", "5分", "10分")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        spinner.setSelection(2)

        findViewById<Button>(R.id.startButton).setOnClickListener { ensurePermissionsAndStart() }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, LoggingService::class.java))
            getSharedPreferences("logger", MODE_PRIVATE).edit().putBoolean("running", false).apply()
            refreshStatus()
        }
        findViewById<Button>(R.id.shareButton).setOnClickListener { shareLatestCsv() }
        findViewById<Button>(R.id.historyButton).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        sim0Map.setOnClickListener { openOutageMap(0) }
        sim1Map.setOnClickListener { openOutageMap(1) }
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        uiHandler.removeCallbacks(refreshRunnable)
        uiHandler.post(refreshRunnable)
    }

    override fun onPause() {
        uiHandler.removeCallbacks(refreshRunnable)
        super.onPause()
    }

    private fun ensurePermissionsAndStart() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startLogger() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startLogger() {
        val millis = when (spinner.selectedItemPosition) {
            0 -> 10_000L; 1 -> 30_000L; 2 -> 60_000L; 3 -> 120_000L; 4 -> 300_000L; else -> 600_000L
        }
        val intent = Intent(this, LoggingService::class.java)
            .putExtra("intervalMs", millis)
            .putExtra("sessionName", sessionName.text.toString())
        ContextCompat.startForegroundService(this, intent)
        getSharedPreferences("logger", MODE_PRIVATE).edit().putBoolean("running", true).apply()
        refreshStatus()
    }

    private fun refreshStatus() {
        val p = getSharedPreferences("logger", MODE_PRIVATE)
        val running = p.getBoolean("running", false)
        status.text = if (running) "● 記録中" else "停止中"
        status.setTextColor(if (running) 0xFFD32F2F.toInt() else 0xFF333333.toInt())

        currentTimeText.text = "現在時刻：" + SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        val lat = p.getString("current_lat", null)?.toDoubleOrNull()
        val lon = p.getString("current_lon", null)?.toDoubleOrNull()
        val acc = p.getString("current_accuracy", null)?.toFloatOrNull()
        val fixMs = p.getLong("last_fix_time_ms", 0L)
        locationText.text = if (lat != null && lon != null) {
            val fix = if (fixMs > 0) SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(fixMs)) else "--:--:--"
            "現在位置：%.6f, %.6f   位置精度 ±%.1fm\n最終測位：%s".format(lat, lon, acc ?: 0f, fix)
        } else {
            "現在位置：取得待ち\n最終測位：--:--:--"
        }

        renderSim(0, sim0Text, sim0Map)
        renderSim(1, sim1Text, sim1Map)

        val publicName = p.getString("public_file_name", null)
        fileText.text = if (publicName != null) {
            "保存先：/storage/emulated/0/Download/SignalLogger/$publicName"
        } else {
            "保存先：/storage/emulated/0/Download/SignalLogger/"
        }
    }

    private fun renderSim(slot: Int, text: TextView, map: Button) {
        val p = getSharedPreferences("logger", MODE_PRIVATE)
        val carrier = p.getString("sim_carrier_$slot", null) ?: "SIM${slot + 1} 取得待ち"
        val service = p.getString("sim_service_$slot", "UNKNOWN") ?: "UNKNOWN"
        val network = p.getString("sim_network_$slot", "UNKNOWN") ?: "UNKNOWN"
        val dbm = p.getString("sim_dbm_$slot", "") ?: ""
        val outageStart = p.getLong("outage_start_ms_$slot", 0L)
        val distance = p.getFloat("outage_distance_m_$slot", 0f)
        val outLat = p.getString("outage_start_lat_$slot", null)?.toDoubleOrNull()
        val outLon = p.getString("outage_start_lon_$slot", null)?.toDoubleOrNull()

        if (service != "IN_SERVICE" && outageStart > 0L) {
            val elapsed = (System.currentTimeMillis() - outageStart).coerceAtLeast(0L)
            val coord = if (outLat != null && outLon != null) "\n圏外開始：%.6f, %.6f".format(outLat, outLon) else "\n圏外開始：座標取得待ち"
            text.text = "$carrier\n圏外  ${formatDuration(elapsed)} / ${formatDistance(distance)}$coord"
            map.visibility = if (outLat != null && outLon != null) View.VISIBLE else View.GONE
        } else {
            val signal = if (dbm.isNotBlank()) " / $dbm dBm" else ""
            text.text = "$carrier\n圏内  $network$signal"
            map.visibility = View.GONE
        }
    }

    private fun formatDuration(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d分%02d秒".format(m, s)
    }

    private fun formatDistance(meters: Float): String =
        if (meters >= 1000f) "%.1fkm".format(meters / 1000f) else "%.0fm".format(meters)

    private fun openOutageMap(slot: Int) {
        val p = getSharedPreferences("logger", MODE_PRIVATE)
        val lat = p.getString("outage_start_lat_$slot", null)?.toDoubleOrNull() ?: return
        val lon = p.getString("outage_start_lon_$slot", null)?.toDoubleOrNull() ?: return
        val carrier = p.getString("sim_carrier_$slot", "SIM${slot + 1}") ?: "SIM${slot + 1}"
        val geo = Uri.parse("geo:$lat,$lon?q=$lat,$lon(${Uri.encode("$carrier 圏外開始地点")})")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, geo))
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lon")))
        }
    }

    private fun shareLatestCsv() {
        val p = getSharedPreferences("logger", MODE_PRIVATE)
        val currentPath = p.getString("current_file", null)
        val dir = getExternalFilesDir("logs")
        val source = currentPath?.let { File(it) }?.takeIf { it.exists() }
            ?: dir?.listFiles()?.filter { it.extension.equals("csv", true) }?.maxByOrNull { it.lastModified() }
        if (source == null) { Toast.makeText(this, "共有できるCSVがありません", Toast.LENGTH_SHORT).show(); return }
        val shareDir = File(cacheDir, "shared_csv").apply { mkdirs() }
        val snapshot = File(shareDir, source.name)
        try { synchronized(LoggingService.FILE_LOCK) { source.copyTo(snapshot, overwrite = true) } }
        catch (e: Exception) { Toast.makeText(this, "CSVの共有準備に失敗", Toast.LENGTH_SHORT).show(); return }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", snapshot)
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"; putExtra(Intent.EXTRA_STREAM, uri); putExtra(Intent.EXTRA_SUBJECT, snapshot.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(share, "CSVを共有・保存"))
    }
}
