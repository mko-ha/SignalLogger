package com.example.signallogger

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.*
import android.telephony.*
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class LoggingService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var intervalMs = 60_000L
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var logFile: File
    private val lastStates = mutableMapOf<Int, Int>()
    private var lastLocation: Location? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        fused = LocationServices.getFusedLocationProviderClient(this)
        val dir = getExternalFilesDir("logs")!!
        dir.mkdirs()
        val name = "signal_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.csv"
        logFile = File(dir, name)
        logFile.writeText("timestamp,latitude,longitude,accuracy_m,sim_slot,subscription_id,carrier,service_state,network_type,dbm,cell_id,tac\n")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intervalMs = intent?.getLongExtra("intervalMs", 60_000L) ?: 60_000L
        startForeground(1001, buildNotification("記録中：${intervalMs / 1000}秒間隔"))
        handler.removeCallbacks(periodic)
        handler.post(periodic)
        startStateWatch()
        return START_STICKY
    }

    private val periodic = object : Runnable {
        override fun run() {
            capture("periodic")
            handler.postDelayed(this, intervalMs)
        }
    }

    private fun capture(reason: String) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        fused.lastLocation.addOnSuccessListener { loc ->
            if (loc != null) lastLocation = loc
            writeTelephonyRows(lastLocation)
        }
    }

    private fun startStateWatch() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        val sm = getSystemService(SubscriptionManager::class.java)
        val tmBase = getSystemService(TelephonyManager::class.java)
        val subs = try { sm.activeSubscriptionInfoList ?: emptyList() } catch (_: SecurityException) { emptyList() }
        for (sub in subs) {
            val tm = tmBase.createForSubscriptionId(sub.subscriptionId)
            tm.registerTelephonyCallback(mainExecutor, object : TelephonyCallback(), TelephonyCallback.ServiceStateListener {
                override fun onServiceStateChanged(serviceState: ServiceState) {
                    val old = lastStates[sub.subscriptionId]
                    lastStates[sub.subscriptionId] = serviceState.state
                    if (old != null && old != serviceState.state) capture("state_change")
                }
            })
        }
    }

    private fun writeTelephonyRows(location: Location?) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        val sm = getSystemService(SubscriptionManager::class.java)
        val tmBase = getSystemService(TelephonyManager::class.java)
        val subs = try { sm.activeSubscriptionInfoList ?: emptyList() } catch (_: SecurityException) { emptyList() }
        val timestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(Date())

        for (sub in subs) {
            val tm = tmBase.createForSubscriptionId(sub.subscriptionId)
            val state = try { serviceStateName(tm.serviceState?.state ?: ServiceState.STATE_OUT_OF_SERVICE) } catch (_: Exception) { "UNKNOWN" }
            val network = try { networkTypeName(tm.dataNetworkType) } catch (_: Exception) { "UNKNOWN" }
            val cells = try { tm.allCellInfo ?: emptyList() } catch (_: Exception) { emptyList() }
            val reg = cells.firstOrNull { it.isRegistered }
            val dbm = signalDbm(reg)
            val (cellId, tac) = cellIdentity(reg)
            val carrier = csv(sub.carrierName?.toString() ?: tm.networkOperatorName ?: "")
            val row = listOf(
                timestamp,
                location?.latitude?.toString() ?: "",
                location?.longitude?.toString() ?: "",
                location?.accuracy?.toString() ?: "",
                sub.simSlotIndex.toString(),
                sub.subscriptionId.toString(),
                carrier,
                state,
                network,
                dbm,
                cellId,
                tac
            ).joinToString(",") + "\n"
            logFile.appendText(row)
        }
    }

    private fun signalDbm(info: CellInfo?): String = try {
        when (info) {
            is CellInfoLte -> info.cellSignalStrength.dbm.toString()
            is CellInfoNr -> info.cellSignalStrength.dbm.toString()
            is CellInfoWcdma -> info.cellSignalStrength.dbm.toString()
            is CellInfoGsm -> info.cellSignalStrength.dbm.toString()
            is CellInfoCdma -> info.cellSignalStrength.dbm.toString()
            else -> ""
        }
    } catch (_: Exception) {
        ""
    }

    private fun cellIdentity(info: CellInfo?): Pair<String, String> = when (info) {
        is CellInfoLte -> info.cellIdentity.ci.toString() to info.cellIdentity.tac.toString()
        is CellInfoNr -> {
            val id = info.cellIdentity as CellIdentityNr
            id.nci.toString() to id.tac.toString()
        }
        is CellInfoWcdma -> info.cellIdentity.cid.toString() to info.cellIdentity.lac.toString()
        is CellInfoGsm -> info.cellIdentity.cid.toString() to info.cellIdentity.lac.toString()
        else -> "" to ""
    }

    private fun serviceStateName(state: Int) = when (state) {
        ServiceState.STATE_IN_SERVICE -> "IN_SERVICE"
        ServiceState.STATE_OUT_OF_SERVICE -> "OUT_OF_SERVICE"
        ServiceState.STATE_EMERGENCY_ONLY -> "EMERGENCY_ONLY"
        ServiceState.STATE_POWER_OFF -> "POWER_OFF"
        else -> "UNKNOWN"
    }

    private fun networkTypeName(type: Int) = when (type) {
        TelephonyManager.NETWORK_TYPE_NR -> "5G_NR"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G_LTE"
        TelephonyManager.NETWORK_TYPE_HSPAP -> "3G_HSPA+"
        TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA -> "3G_HSPA"
        TelephonyManager.NETWORK_TYPE_UMTS -> "3G_UMTS"
        TelephonyManager.NETWORK_TYPE_EDGE -> "2G_EDGE"
        TelephonyManager.NETWORK_TYPE_GPRS -> "2G_GPRS"
        0 -> "NONE"
        else -> "TYPE_$type"
    }

    private fun csv(s: String) = "\"${s.replace("\"", "\"\"")}\""

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("logging", "電波記録", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, "logging")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("電波ロガー")
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
