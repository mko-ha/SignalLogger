# SignalLogger Pro v2.3.3

v2.3.1 の電波取得処理とシンプルUIを維持し、保存・過去CSV・変換機能を追加。

- 記録中の本体CSVは従来どおりアプリ領域へ逐次保存
- 同時に `Download/SignalLogger/` に公開CSVを逐次自動保存
- 公開CSVはアプリをアンインストールしてもファイル管理から確認しやすい
- 「記録フォルダ・過去CSV」から過去CSV一覧を表示
- 保存済みCSVを選択し、GPX / KML / 両方へ手動変換
- 変換は元CSVを変更しない
- GPX/KMLは `Download/SignalLogger/` に保存
- 記録中はGPX/KMLを生成しないため、ロガー本体の安定性を優先
