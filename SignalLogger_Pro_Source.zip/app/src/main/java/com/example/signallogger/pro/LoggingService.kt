package com.example.signallogger.pro

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.os.*
import android.provider.Settings
import android.telephony.*
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap

class LoggingService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var fused: FusedLocationProviderClient
    private lateinit var logFile: File
    private var intervalMs = 60_000L
    private var lastLocation: Location? = null
    private var rowCount = 0L
    private var wakeLock: PowerManager.WakeLock? = null

    private data class SubState(
        var serviceState: ServiceState? = null,
        var signalStrength: SignalStrength? = null,
        var displayInfo: TelephonyDisplayInfo? = null,
        var cellInfo: List<CellInfo> = emptyList(),
        var lastServiceName: String = "UNKNOWN",
        var lastNetworkName: String = "UNKNOWN",
        var lastCellKey: String = ""
    )

    private val states = ConcurrentHashMap<Int, SubState>()
    private val callbacks = ConcurrentHashMap<Int, TelephonyCallback>()
    private val telephonyManagers = ConcurrentHashMap<Int, TelephonyManager>()

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val best = result.lastLocation ?: return
            lastLocation = best
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        fused = LocationServices.getFusedLocationProviderClient(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intervalMs = intent?.getLongExtra("intervalMs", 60_000L) ?: 60_000L
        prefs().edit().putBoolean("running", true).apply()
        if (!::logFile.isInitialized) {
            createLogFile(intent?.getStringExtra("sessionName"))
        }

        startForeground(1001, buildNotification("記録中：${intervalLabel(intervalMs)}"))
        acquireWakeLock()
        startLocationUpdates()
        startTelephonyWatch()

        handler.removeCallbacks(periodic)
        handler.post(periodic)
        return START_STICKY
    }

    private fun createLogFile(sessionName: String?) {
        val dir = getExternalFilesDir("logs") ?: filesDir
        dir.mkdirs()
        val safe = sessionName.orEmpty()
            .trim()
            .replace(Regex("[^A-Za-z0-9_\\-ぁ-んァ-ヶ一-龠]"), "_")
            .take(30)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = if (safe.isBlank()) "signal_$stamp.csv" else "signal_${stamp}_$safe.csv"
        logFile = File(dir, name)
        logFile.writeText(
            "timestamp,reason,latitude,longitude,accuracy_m,location_age_ms,provider,speed_mps,bearing_deg," +
            "sim_slot,subscription_id,is_embedded,carrier,mcc,mnc,service_state,network_type,dbm," +
            "rsrp,rsrq,rssnr,ss_rsrp,ss_rsrq,ss_sinr,cell_id,tac_lac,pci,arfcn,roaming,data_state," +
            "battery_pct,charging,power_save,airplane_mode\n"
        )
        prefs().edit().putString("current_file", logFile.absolutePath).putLong("row_count", 0).apply()
    }

    private val periodic = object : Runnable {
        override fun run() {
            capture("PERIODIC")
            handler.postDelayed(this, intervalMs)
        }
    }

    private fun capture(reason: String) {
        if (!hasLocationPermission()) {
            writeTelephonyRows(lastLocation, reason)
            return
        }

        val loc = lastLocation
        val stale = loc == null || (SystemClock.elapsedRealtimeNanos() - loc.elapsedRealtimeNanos) / 1_000_000 > 20_000
        if (!stale) {
            writeTelephonyRows(loc, reason)
            return
        }

        fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
            .addOnSuccessListener { fresh ->
                if (fresh != null) lastLocation = fresh
                writeTelephonyRows(lastLocation, reason)
            }
            .addOnFailureListener {
                writeTelephonyRows(lastLocation, reason)
            }
    }

    private fun startLocationUpdates() {
        if (!hasLocationPermission()) return
        val updateMs = (intervalMs / 2).coerceIn(3_000L, 15_000L)
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, updateMs)
            .setMinUpdateIntervalMillis(2_000L)
            .setMinUpdateDistanceMeters(0f)
            .build()
        fused.removeLocationUpdates(locationCallback)
        fused.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
    }

    private fun startTelephonyWatch() {
        if (!hasPhonePermission()) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return

        val sm = getSystemService(SubscriptionManager::class.java)
        val tmBase = getSystemService(TelephonyManager::class.java)
        val subs = try { sm.activeSubscriptionInfoList ?: emptyList() } catch (_: SecurityException) { emptyList() }

        for (sub in subs) {
            if (callbacks.containsKey(sub.subscriptionId)) continue

            val subId = sub.subscriptionId
            val tm = tmBase.createForSubscriptionId(subId)
            telephonyManagers[subId] = tm
            val state = states.getOrPut(subId) { SubState() }

            val cb = object : TelephonyCallback(),
                TelephonyCallback.ServiceStateListener,
                TelephonyCallback.SignalStrengthsListener,
                TelephonyCallback.DisplayInfoListener,
                TelephonyCallback.CellInfoListener,
                TelephonyCallback.DataConnectionStateListener {

                override fun onServiceStateChanged(newState: ServiceState) {
                    val oldName = state.lastServiceName
                    state.serviceState = newState
                    val newName = serviceStateName(newState.state)
                    state.lastServiceName = newName
                    if (oldName != "UNKNOWN" && oldName != newName) {
                        val reason = when {
                            oldName == "IN_SERVICE" && newName != "IN_SERVICE" -> "SERVICE_LOST"
                            oldName != "IN_SERVICE" && newName == "IN_SERVICE" -> "SERVICE_RESTORED"
                            else -> "SERVICE_STATE_CHANGED"
                        }
                        capture(reason)
                    }
                }

                override fun onSignalStrengthsChanged(signalStrength: SignalStrength) {
                    state.signalStrength = signalStrength
                }

                override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) {
                    state.displayInfo = telephonyDisplayInfo
                    val tmNow = telephonyManagers[subId]
                    val newNetwork = effectiveNetworkName(tmNow, state)
                    val oldNetwork = state.lastNetworkName
                    state.lastNetworkName = newNetwork
                    if (oldNetwork != "UNKNOWN" && oldNetwork != newNetwork) {
                        capture("NETWORK_CHANGED")
                    }
                }

                override fun onCellInfoChanged(cellInfo: MutableList<CellInfo>) {
                    state.cellInfo = cellInfo
                    val newKey = registeredCellKey(cellInfo)
                    val oldKey = state.lastCellKey
                    state.lastCellKey = newKey
                    if (oldKey.isNotBlank() && newKey.isNotBlank() && oldKey != newKey) {
                        capture("CELL_CHANGED")
                    }
                }

                override fun onDataConnectionStateChanged(dataState: Int, networkType: Int) {
                    // The current value is read when a row is written.
                }
            }

            try {
                tm.registerTelephonyCallback(mainExecutor, cb)
                callbacks[subId] = cb
                seedState(tm, state)
                requestFreshCellInfo(tm, state)
            } catch (_: Exception) {
            }
        }
    }

    private fun seedState(tm: TelephonyManager, state: SubState) {
        try { state.serviceState = tm.serviceState } catch (_: Exception) {}
        try {
            val cells = tm.allCellInfo ?: emptyList()
            if (cells.isNotEmpty()) state.cellInfo = cells
        } catch (_: Exception) {}
        state.lastServiceName = serviceStateName(state.serviceState?.state ?: ServiceState.STATE_OUT_OF_SERVICE)
        state.lastNetworkName = effectiveNetworkName(tm, state)
        state.lastCellKey = registeredCellKey(state.cellInfo)
    }

    private fun requestFreshCellInfo(tm: TelephonyManager, state: SubState) {
        if (!hasLocationPermission()) return
        try {
            tm.requestCellInfoUpdate(mainExecutor, object : TelephonyManager.CellInfoCallback() {
                override fun onCellInfo(cellInfo: MutableList<CellInfo>) {
                    if (cellInfo.isNotEmpty()) state.cellInfo = cellInfo
                }
            })
        } catch (_: Exception) {}
    }

    private fun writeTelephonyRows(location: Location?, reason: String) {
        if (!hasPhonePermission() || !::logFile.isInitialized) return

        val sm = getSystemService(SubscriptionManager::class.java)
        val tmBase = getSystemService(TelephonyManager::class.java)
        val subs = try { sm.activeSubscriptionInfoList ?: emptyList() } catch (_: SecurityException) { emptyList() }
        val timestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(Date())
        val battery = batteryInfo()
        val powerSave = getSystemService(PowerManager::class.java).isPowerSaveMode
        val airplane = try { Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1 } catch (_: Exception) { false }

        for (sub in subs) {
            val tm = telephonyManagers[sub.subscriptionId] ?: tmBase.createForSubscriptionId(sub.subscriptionId)
            telephonyManagers[sub.subscriptionId] = tm
            val st = states.getOrPut(sub.subscriptionId) { SubState() }

            requestFreshCellInfo(tm, st)

            val svc = st.serviceState ?: try { tm.serviceState } catch (_: Exception) { null }
            val serviceName = if (airplane) "POWER_OFF" else serviceStateName(svc?.state ?: ServiceState.STATE_OUT_OF_SERVICE)
            val network = effectiveNetworkName(tm, st)

            val cells = st.cellInfo.ifEmpty {
                try { tm.allCellInfo ?: emptyList() } catch (_: Exception) { emptyList() }
            }
            if (cells.isNotEmpty()) st.cellInfo = cells
            val registered = cells.firstOrNull { it.isRegistered }

            val metrics = signalMetrics(st.signalStrength, registered)
            val cell = cellMetrics(registered)
            val carrier = sub.carrierName?.toString() ?: try { tm.networkOperatorName } catch (_: Exception) { "" }
            val dataState = try { dataStateName(tm.dataState) } catch (_: Exception) { "UNKNOWN" }
            val roaming = try { tm.isNetworkRoaming } catch (_: Exception) { false }

            val locationAge = location?.let {
                ((SystemClock.elapsedRealtimeNanos() - it.elapsedRealtimeNanos) / 1_000_000).coerceAtLeast(0)
            }

            val row = listOf(
                timestamp,
                reason,
                location?.latitude?.toString().orEmpty(),
                location?.longitude?.toString().orEmpty(),
                location?.accuracy?.toString().orEmpty(),
                locationAge?.toString().orEmpty(),
                location?.provider.orEmpty(),
                if (location?.hasSpeed() == true) location.speed.toString() else "",
                if (location?.hasBearing() == true) location.bearing.toString() else "",
                sub.simSlotIndex.toString(),
                sub.subscriptionId.toString(),
                sub.isEmbedded.toString(),
                carrier,
                sub.mccString.orEmpty(),
                sub.mncString.orEmpty(),
                serviceName,
                network,
                metrics.dbm,
                metrics.rsrp,
                metrics.rsrq,
                metrics.rssnr,
                metrics.ssRsrp,
                metrics.ssRsrq,
                metrics.ssSinr,
                cell.cellId,
                cell.tacLac,
                cell.pci,
                cell.arfcn,
                roaming.toString(),
                dataState,
                battery.first.toString(),
                battery.second.toString(),
                powerSave.toString(),
                airplane.toString()
            ).joinToString(",") { csvField(it) } + "\n"

            synchronized(this) { logFile.appendText(row) }
            rowCount++
            prefs().edit()
                .putLong("row_count", rowCount)
                .putString(
                    "sim_${sub.simSlotIndex}",
                    "SIM${sub.simSlotIndex + 1}: ${carrier.ifBlank { "不明" }} / $serviceName / $network / ${metrics.dbm.ifBlank { "--" }} dBm"
                )
                .apply()
        }

        prefs().edit().putLong("last_write", System.currentTimeMillis()).apply()
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(1001, buildNotification("記録中：${intervalLabel(intervalMs)} / ${rowCount}行"))
    }

    private data class SignalMetrics(
        val dbm: String = "",
        val rsrp: String = "",
        val rsrq: String = "",
        val rssnr: String = "",
        val ssRsrp: String = "",
        val ssRsrq: String = "",
        val ssSinr: String = ""
    )

    private fun signalMetrics(signal: SignalStrength?, registered: CellInfo?): SignalMetrics {
        val strengths = try { signal?.cellSignalStrengths ?: emptyList() } catch (_: Exception) { emptyList() }

        val preferred: CellSignalStrength? = when (registered) {
            is CellInfoNr -> strengths.filterIsInstance<CellSignalStrengthNr>().firstOrNull()
            is CellInfoLte -> strengths.filterIsInstance<CellSignalStrengthLte>().firstOrNull()
            is CellInfoWcdma -> strengths.filterIsInstance<CellSignalStrengthWcdma>().firstOrNull()
            is CellInfoGsm -> strengths.filterIsInstance<CellSignalStrengthGsm>().firstOrNull()
            is CellInfoCdma -> strengths.filterIsInstance<CellSignalStrengthCdma>().firstOrNull()
            else -> strengths.maxByOrNull { it.level }
        }

        val dbm = valid(preferred?.dbm)
            ?: valid(signalDbmFromCell(registered))
            ?: ""

        return when (preferred) {
            is CellSignalStrengthLte -> SignalMetrics(
                dbm = dbm,
                rsrp = valid(preferred.rsrp) ?: "",
                rsrq = valid(preferred.rsrq) ?: "",
                rssnr = valid(preferred.rssnr) ?: ""
            )
            is CellSignalStrengthNr -> SignalMetrics(
                dbm = dbm,
                ssRsrp = valid(preferred.ssRsrp) ?: "",
                ssRsrq = valid(preferred.ssRsrq) ?: "",
                ssSinr = valid(preferred.ssSinr) ?: ""
            )
            else -> SignalMetrics(dbm = dbm)
        }
    }

    private fun signalDbmFromCell(info: CellInfo?): Int? = try {
        when (info) {
            is CellInfoLte -> info.cellSignalStrength.dbm
            is CellInfoNr -> info.cellSignalStrength.dbm
            is CellInfoWcdma -> info.cellSignalStrength.dbm
            is CellInfoGsm -> info.cellSignalStrength.dbm
            is CellInfoCdma -> info.cellSignalStrength.dbm
            else -> null
        }
    } catch (_: Exception) { null }

    private fun valid(value: Int?): String? {
        if (value == null || value == Int.MAX_VALUE || value == CellInfo.UNAVAILABLE) return null
        return value.toString()
    }

    private data class CellMetrics(
        val cellId: String = "",
        val tacLac: String = "",
        val pci: String = "",
        val arfcn: String = ""
    )

    private fun cellMetrics(info: CellInfo?): CellMetrics = try {
        when (info) {
            is CellInfoLte -> {
                val id = info.cellIdentity
                CellMetrics(validId(id.ci), validId(id.tac), validId(id.pci), validId(id.earfcn))
            }
            is CellInfoNr -> {
                val id = info.cellIdentity as CellIdentityNr
                CellMetrics(validLongId(id.nci), validId(id.tac), validId(id.pci), validId(id.nrarfcn))
            }
            is CellInfoWcdma -> {
                val id = info.cellIdentity
                CellMetrics(validId(id.cid), validId(id.lac), validId(id.psc), validId(id.uarfcn))
            }
            is CellInfoGsm -> {
                val id = info.cellIdentity
                CellMetrics(validId(id.cid), validId(id.lac), validId(id.bsic), validId(id.arfcn))
            }
            is CellInfoCdma -> {
                val id = info.cellIdentity
                CellMetrics(validId(id.basestationId), validId(id.networkId), "", "")
            }
            else -> CellMetrics()
        }
    } catch (_: Exception) { CellMetrics() }

    private fun validId(v: Int): String =
        if (v == Int.MAX_VALUE || v == CellInfo.UNAVAILABLE || v < 0) "" else v.toString()

    private fun validLongId(v: Long): String =
        if (v == Long.MAX_VALUE || v < 0L) "" else v.toString()

    private fun registeredCellKey(cells: List<CellInfo>): String {
        val c = cells.firstOrNull { it.isRegistered } ?: return ""
        val m = cellMetrics(c)
        return "${c.javaClass.simpleName}:${m.cellId}:${m.tacLac}:${m.pci}:${m.arfcn}"
    }

    private fun effectiveNetworkName(tm: TelephonyManager?, state: SubState): String {
        val di = state.displayInfo
        if (di != null) {
            when (di.overrideNetworkType) {
                TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA,
                TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_ADVANCED -> return "5G_NR_NSA"
            }
            if (di.networkType != TelephonyManager.NETWORK_TYPE_UNKNOWN) {
                return networkTypeName(di.networkType)
            }
        }

        if (tm != null) {
            val data = try { tm.dataNetworkType } catch (_: Exception) { TelephonyManager.NETWORK_TYPE_UNKNOWN }
            if (data != TelephonyManager.NETWORK_TYPE_UNKNOWN) return networkTypeName(data)
            val voice = try { tm.voiceNetworkType } catch (_: Exception) { TelephonyManager.NETWORK_TYPE_UNKNOWN }
            if (voice != TelephonyManager.NETWORK_TYPE_UNKNOWN) return networkTypeName(voice)
        }

        val registered = state.cellInfo.firstOrNull { it.isRegistered }
        return when (registered) {
            is CellInfoNr -> "5G_NR"
            is CellInfoLte -> "4G_LTE"
            is CellInfoWcdma -> "3G_WCDMA"
            is CellInfoGsm -> "2G_GSM"
            is CellInfoCdma -> "CDMA"
            else -> "UNKNOWN"
        }
    }

    private fun networkTypeName(type: Int): String = when (type) {
        TelephonyManager.NETWORK_TYPE_NR -> "5G_NR"
        TelephonyManager.NETWORK_TYPE_LTE -> "4G_LTE"
        TelephonyManager.NETWORK_TYPE_IWLAN -> "IWLAN"
        TelephonyManager.NETWORK_TYPE_HSPAP -> "3G_HSPA+"
        TelephonyManager.NETWORK_TYPE_HSPA,
        TelephonyManager.NETWORK_TYPE_HSDPA,
        TelephonyManager.NETWORK_TYPE_HSUPA -> "3G_HSPA"
        TelephonyManager.NETWORK_TYPE_UMTS -> "3G_UMTS"
        TelephonyManager.NETWORK_TYPE_EDGE -> "2G_EDGE"
        TelephonyManager.NETWORK_TYPE_GPRS -> "2G_GPRS"
        TelephonyManager.NETWORK_TYPE_GSM -> "2G_GSM"
        TelephonyManager.NETWORK_TYPE_CDMA,
        TelephonyManager.NETWORK_TYPE_1xRTT,
        TelephonyManager.NETWORK_TYPE_EVDO_0,
        TelephonyManager.NETWORK_TYPE_EVDO_A,
        TelephonyManager.NETWORK_TYPE_EVDO_B -> "CDMA"
        TelephonyManager.NETWORK_TYPE_UNKNOWN -> "UNKNOWN"
        else -> "TYPE_$type"
    }

    private fun serviceStateName(state: Int): String = when (state) {
        ServiceState.STATE_IN_SERVICE -> "IN_SERVICE"
        ServiceState.STATE_OUT_OF_SERVICE -> "OUT_OF_SERVICE"
        ServiceState.STATE_EMERGENCY_ONLY -> "EMERGENCY_ONLY"
        ServiceState.STATE_POWER_OFF -> "POWER_OFF"
        else -> "UNKNOWN"
    }

    private fun dataStateName(state: Int): String = when (state) {
        TelephonyManager.DATA_CONNECTED -> "CONNECTED"
        TelephonyManager.DATA_CONNECTING -> "CONNECTING"
        TelephonyManager.DATA_DISCONNECTED -> "DISCONNECTED"
        TelephonyManager.DATA_SUSPENDED -> "SUSPENDED"
        TelephonyManager.DATA_DISCONNECTING -> "DISCONNECTING"
        TelephonyManager.DATA_HANDOVER_IN_PROGRESS -> "HANDOVER"
        else -> "UNKNOWN"
    }

    private fun batteryInfo(): Pair<Int, Boolean> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return pct to charging
    }

    private fun hasLocationPermission(): Boolean =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun hasPhonePermission(): Boolean =
        ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun csvField(v: String): String =
        if (v.contains(',') || v.contains('"') || v.contains('\n')) "\"${v.replace("\"", "\"\"")}\"" else v

    private fun prefs() = getSharedPreferences("logger", Context.MODE_PRIVATE)

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:SignalLogger").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun intervalLabel(ms: Long): String = when (ms) {
        10_000L -> "10秒"
        30_000L -> "30秒"
        60_000L -> "1分"
        120_000L -> "2分"
        300_000L -> "5分"
        600_000L -> "10分"
        else -> "${ms / 1000}秒"
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("logging", "電波記録", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun buildNotification(text: String): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, "logging")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("SignalLogger Pro")
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { fused.removeLocationUpdates(locationCallback) } catch (_: Exception) {}

        for ((subId, cb) in callbacks) {
            try { telephonyManagers[subId]?.unregisterTelephonyCallback(cb) } catch (_: Exception) {}
        }
        callbacks.clear()
        telephonyManagers.clear()

        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {}

        prefs().edit().putBoolean("running", false).apply()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
