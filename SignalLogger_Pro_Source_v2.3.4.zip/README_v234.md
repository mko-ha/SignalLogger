# SignalLogger Pro v2.3.4

- v2.3.3をベースにUIを圧縮し、通常は1画面で確認できる構成
- 現在時刻を常時表示
- 現在座標、位置精度、最終測位時刻を常時表示
- SIMごとに圏外開始時刻・圏外経過時間・圏外中のGPS累積移動距離を保持
- 圏外開始地点の緯度経度を表示し、「地図」から端末の地図アプリへ移動
- 通知にキャリア、圏内/圏外、通信方式、dBm（圏内のみ）、圏外経過時間・距離を表示
- CSVへ outage_start_time / outage_start_lat / outage_start_lon / outage_elapsed_ms / outage_distance_m を追加
- CSVは Download/SignalLogger/ へ逐次保存。GPX/KML変換は保存後CSVから実行
- 保存先フルパスを画面に常時表示
- アプリ名は SignalLogger Pro、applicationId は com.example.signallogger.pro234（旧版と共存）
