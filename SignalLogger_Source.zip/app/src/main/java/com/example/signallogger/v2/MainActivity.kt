package com.example.signallogger.v2

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.widget.*
import android.graphics.Color
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var status: TextView
    private lateinit var fileText: TextView
    private lateinit var liveText: TextView
    private lateinit var sessionName: EditText
    private lateinit var rootView: View
    private val uiHandler = Handler(Looper.getMainLooper())

    private val refreshRunnable = object : Runnable {
        override fun run() {
            refreshStatus()
            uiHandler.postDelayed(this, 2000)
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val phone = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        if (fine && phone) startLogger()
        else status.text = "位置情報と電話の権限が必要です"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinner = findViewById(R.id.intervalSpinner)
        status = findViewById(R.id.statusText)
        fileText = findViewById(R.id.fileText)
        liveText = findViewById(R.id.liveText)
        sessionName = findViewById(R.id.sessionName)
        rootView = findViewById(R.id.rootView)

        val labels = listOf("10秒", "30秒", "1分", "2分", "5分", "10分")
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        spinner.setSelection(2)

        findViewById<Button>(R.id.startButton).setOnClickListener { ensurePermissionsAndStart() }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, LoggingService::class.java))
            getSharedPreferences("logger", MODE_PRIVATE).edit().putBoolean("running", false).apply()
            status.text = "停止中"
            refreshStatus()
        }
        findViewById<Button>(R.id.shareButton).setOnClickListener { shareLatestCsv() }
        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        uiHandler.removeCallbacks(refreshRunnable)
        uiHandler.post(refreshRunnable)
    }

    override fun onPause() {
        uiHandler.removeCallbacks(refreshRunnable)
        super.onPause()
    }

    private fun ensurePermissionsAndStart() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startLogger() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startLogger() {
        val millis = when (spinner.selectedItemPosition) {
            0 -> 10_000L
            1 -> 30_000L
            2 -> 60_000L
            3 -> 120_000L
            4 -> 300_000L
            else -> 600_000L
        }
        val intent = Intent(this, LoggingService::class.java)
            .putExtra("intervalMs", millis)
            .putExtra("sessionName", sessionName.text.toString())
        ContextCompat.startForegroundService(this, intent)
        getSharedPreferences("logger", MODE_PRIVATE).edit().putBoolean("running", true).apply()
        status.text = "記録開始：${spinner.selectedItem}"
    }

    private fun refreshStatus() {
        val p = getSharedPreferences("logger", MODE_PRIVATE)
        val running = p.getBoolean("running", false)
        val rows = p.getLong("row_count", 0)
        status.text = if (running) "● 記録中 / ${rows}行" else "停止中"
        rootView.setBackgroundColor(if (running) Color.rgb(255, 205, 205) else Color.WHITE)

        val sim0 = p.getString("sim_0", null)
        val sim1 = p.getString("sim_1", null)
        liveText.text = listOfNotNull(sim0, sim1).ifEmpty { listOf("SIM情報は記録開始後に表示されます") }.joinToString("\n")

        val current = p.getString("current_file", null)
        fileText.text = current?.let { "CSV:\n$it" } ?: "CSVはまだありません"
    }

    private fun shareLatestCsv() {
        val dir = getExternalFilesDir("logs")
        val latest = dir?.listFiles()
            ?.filter { it.extension.equals("csv", true) }
            ?.maxByOrNull { it.lastModified() }

        if (latest == null) {
            status.text = "共有できるCSVがありません"
            return
        }

        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", latest)
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, latest.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(share, "CSVを共有・保存"))
    }
}
