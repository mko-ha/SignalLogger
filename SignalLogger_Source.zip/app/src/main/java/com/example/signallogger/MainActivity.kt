package com.example.signallogger

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var status: TextView
    private lateinit var fileText: TextView

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.entries.all { it.value }) startLogger() else status.text = "必要な権限が許可されていません"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        spinner = findViewById(R.id.intervalSpinner)
        status = findViewById(R.id.statusText)
        fileText = findViewById(R.id.fileText)

        val labels = listOf("10秒", "30秒", "1分", "2分", "5分", "10分")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.setSelection(2)

        findViewById<Button>(R.id.startButton).setOnClickListener { ensurePermissionsAndStart() }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, LoggingService::class.java))
            status.text = "停止中"
        }
        findViewById<Button>(R.id.shareButton).setOnClickListener { shareLatestCsv() }
        refreshFileText()
    }

    private fun ensurePermissionsAndStart() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
        )
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startLogger() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startLogger() {
        val millis = when (spinner.selectedItemPosition) {
            0 -> 10_000L
            1 -> 30_000L
            2 -> 60_000L
            3 -> 120_000L
            4 -> 300_000L
            else -> 600_000L
        }
        val intent = Intent(this, LoggingService::class.java).putExtra("intervalMs", millis)
        ContextCompat.startForegroundService(this, intent)
        status.text = "記録中：${spinner.selectedItem}ごと"
        refreshFileText()
    }

    private fun refreshFileText() {
        val dir = getExternalFilesDir("logs")
        val latest = dir?.listFiles()?.filter { it.extension == "csv" }?.maxByOrNull { it.lastModified() }
        fileText.text = latest?.let { "最新ログ：\n${it.absolutePath}" } ?: "CSVはまだありません"
    }

    private fun shareLatestCsv() {
        val dir = getExternalFilesDir("logs")
        val latest = dir?.listFiles()?.filter { it.extension == "csv" }?.maxByOrNull { it.lastModified() }
        if (latest == null) {
            status.text = "共有できるCSVがありません"
            return
        }
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", latest)
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(share, "CSVを共有"))
    }
}
