package com.example.signallogger.pro

import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import java.io.BufferedReader
import java.io.InputStreamReader

object PublicLogStore {
    const val RELATIVE_PATH = "Download/SignalLogger/"

    data class Entry(val uri: Uri, val name: String, val size: Long, val modifiedSeconds: Long)

    fun create(context: Context, displayName: String, mime: String): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, RELATIVE_PATH)
        }
        return try {
            context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        } catch (_: Exception) { null }
    }

    fun writeText(context: Context, uri: Uri, text: String, append: Boolean): Boolean {
        return try {
            val mode = if (append) "wa" else "wt"
            context.contentResolver.openOutputStream(uri, mode)?.use { out ->
                out.write(text.toByteArray(Charsets.UTF_8))
                out.flush()
            } ?: return false
            true
        } catch (_: Exception) { false }
    }

    fun copyLocalFile(context: Context, uri: Uri, file: java.io.File): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                file.inputStream().use { input -> input.copyTo(out) }
                out.flush()
            } ?: return false
            true
        } catch (_: Exception) { false }
    }

    fun listCsv(context: Context): List<Entry> {
        val result = mutableListOf<Entry>()
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED
        )
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ?"
        val args = arrayOf(RELATIVE_PATH, "%.csv")
        val sort = "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        try {
            context.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                projection, selection, args, sort
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val modCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    result += Entry(
                        ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id),
                        c.getString(nameCol), c.getLong(sizeCol), c.getLong(modCol)
                    )
                }
            }
        } catch (_: Exception) {}
        return result
    }

    data class TrackPoint(val timestamp: String, val lat: Double, val lon: Double, val accuracy: String)

    fun readTrackPoints(context: Context, uri: Uri): List<TrackPoint> {
        val points = mutableListOf<TrackPoint>()
        val seen = HashSet<String>()
        context.contentResolver.openInputStream(uri)?.use { ins ->
            BufferedReader(InputStreamReader(ins, Charsets.UTF_8)).use { br ->
                val headerLine = br.readLine() ?: return emptyList()
                val header = parseCsvLine(headerLine)
                val timeIndex = header.indexOf("timestamp")
                val latIndex = header.indexOf("latitude")
                val lonIndex = header.indexOf("longitude")
                val accIndex = header.indexOf("accuracy_m")
                if (timeIndex < 0 || latIndex < 0 || lonIndex < 0) return emptyList()
                var line: String?
                while (br.readLine().also { line = it } != null) {
                    val cols = parseCsvLine(line ?: continue)
                    if (cols.size <= maxOf(timeIndex, latIndex, lonIndex)) continue
                    val lat = cols[latIndex].toDoubleOrNull() ?: continue
                    val lon = cols[lonIndex].toDoubleOrNull() ?: continue
                    val ts = cols[timeIndex]
                    val key = "$ts|$lat|$lon"
                    if (!seen.add(key)) continue
                    val acc = if (accIndex >= 0 && accIndex < cols.size) cols[accIndex] else ""
                    points += TrackPoint(ts, lat, lon, acc)
                }
            }
        }
        return points
    }

    fun convertToGpx(context: Context, source: Entry): Uri? {
        val points = readTrackPoints(context, source.uri)
        if (points.isEmpty()) return null
        val base = source.name.substringBeforeLast('.')
        val xml = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
            append("<gpx version=\"1.1\" creator=\"SignalLogger Pro\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n")
            append("<trk><name>${xmlEscape(base)}</name><trkseg>\n")
            for (p in points) {
                append("<trkpt lat=\"${p.lat}\" lon=\"${p.lon}\">")
                if (p.timestamp.isNotBlank()) append("<time>${xmlEscape(p.timestamp)}</time>")
                if (p.accuracy.isNotBlank()) append("<extensions><accuracy>${xmlEscape(p.accuracy)}</accuracy></extensions>")
                append("</trkpt>\n")
            }
            append("</trkseg></trk></gpx>\n")
        }
        val out = create(context, "$base.gpx", "application/gpx+xml") ?: return null
        return if (writeText(context, out, xml, false)) out else null
    }

    fun convertToKml(context: Context, source: Entry): Uri? {
        val points = readTrackPoints(context, source.uri)
        if (points.isEmpty()) return null
        val base = source.name.substringBeforeLast('.')
        val xml = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
            append("<kml xmlns=\"http://www.opengis.net/kml/2.2\"><Document>")
            append("<name>${xmlEscape(base)}</name><Placemark><name>${xmlEscape(base)}</name><LineString><tessellate>1</tessellate><coordinates>\n")
            for (p in points) append("${p.lon},${p.lat},0\n")
            append("</coordinates></LineString></Placemark></Document></kml>\n")
        }
        val out = create(context, "$base.kml", "application/vnd.google-earth.kml+xml") ?: return null
        return if (writeText(context, out, xml, false)) out else null
    }

    private fun parseCsvLine(line: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> { out += sb.toString(); sb.setLength(0) }
                else -> sb.append(ch)
            }
            i++
        }
        out += sb.toString()
        return out
    }

    private fun xmlEscape(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")
}
