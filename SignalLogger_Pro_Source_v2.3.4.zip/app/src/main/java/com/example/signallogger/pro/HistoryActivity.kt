package com.example.signallogger.pro

import android.content.Intent
import android.os.Bundle
import android.text.format.Formatter
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class HistoryActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var emptyText: TextView
    private var entries: List<PublicLogStore.Entry> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
        }
        root.addView(TextView(this).apply {
            text = "記録フォルダ / 過去のCSV"
            textSize = 24f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "保存先: Download/SignalLogger/\nCSVをタップするとGPX/KMLへ変換できます。元CSVは変更しません。"
            textSize = 14f
            setPadding(0, 12, 0, 12)
        })
        root.addView(Button(this).apply {
            text = "一覧を更新"
            setOnClickListener { refresh() }
        })
        emptyText = TextView(this).apply { text = "過去のCSVはありません"; setPadding(0, 18, 0, 8) }
        root.addView(emptyText)
        listView = ListView(this)
        root.addView(listView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        listView.setOnItemClickListener { _, _, position, _ -> showActions(entries[position]) }
        refresh()
    }

    private fun refresh() {
        entries = PublicLogStore.listCsv(this)
        emptyText.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
        val df = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
        val labels = entries.map {
            val d = if (it.modifiedSeconds > 0) df.format(Date(it.modifiedSeconds * 1000)) else ""
            "${it.name}\n$d  ${Formatter.formatShortFileSize(this, it.size)}"
        }
        listView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
    }

    private fun showActions(entry: PublicLogStore.Entry) {
        val options = arrayOf("共有", "GPXに変換", "KMLに変換", "GPX + KMLに変換")
        AlertDialog.Builder(this)
            .setTitle(entry.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> share(entry)
                    1 -> convert(entry, true, false)
                    2 -> convert(entry, false, true)
                    3 -> convert(entry, true, true)
                }
            }.show()
    }

    private fun share(entry: PublicLogStore.Entry) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, entry.uri)
            putExtra(Intent.EXTRA_SUBJECT, entry.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(i, "CSVを共有"))
    }

    private fun convert(entry: PublicLogStore.Entry, gpx: Boolean, kml: Boolean) {
        Thread {
            val gpxOk = !gpx || PublicLogStore.convertToGpx(this, entry) != null
            val kmlOk = !kml || PublicLogStore.convertToKml(this, entry) != null
            runOnUiThread {
                if (gpxOk && kmlOk) {
                    Toast.makeText(this, "Download/SignalLogger に変換して保存しました", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "変換できませんでした。GPS座標を含むCSVか確認してください", Toast.LENGTH_LONG).show()
                }
                refresh()
            }
        }.start()
    }
}
