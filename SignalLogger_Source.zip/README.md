# SignalLogger v2

Android 12+ 向けのデュアルSIM電波・位置情報ロガーです。

## v2 主な変更
- TelephonyCallback.SignalStrengthsListener を利用して dBm をSIMごとに取得
- LTE: RSRP / RSRQ / RSSNR、5G NR: SS-RSRP / SS-RSRQ / SS-SINR
- TelephonyDisplayInfo + dataNetworkType + voiceNetworkType + CellInfo の順で通信方式を補完
- CellInfoListener + requestCellInfoUpdate() で Cell ID / TAC(LAC) / PCI / ARFCN を強化
- 高精度Fused Locationを継続取得。位置の鮮度(location_age_ms)も記録
- 圏外/復帰、4G/5G変更、Cell変更を即時追加記録
- reason列: PERIODIC / SERVICE_LOST / SERVICE_RESTORED / NETWORK_CHANGED / CELL_CHANGED
- eSIM判定、MCC/MNC、roaming、data_state
- バッテリー残量、充電状態、省電力、機内モード
- セッション名付きCSV
- WakeLock + Foreground Service で画面OFF時の継続性を強化
- アプリ画面でSIMごとの最新状態を表示

## 注意
Android端末・キャリア・モデム実装によって取得できないセル情報は空欄になります。値は推測しません。
高精度GPSとWakeLockを使用するため、記録中はバッテリー消費が増えます。

- アプリ表示名は SignalLogger のまま維持
- 記録中は画面背景を薄い赤に変更し、停止すると白に戻る
