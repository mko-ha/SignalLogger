package com.example.signallogger.pro

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.*
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.location.Priority
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var intervalSpinner: Spinner
    private lateinit var gpsSpinner: Spinner
    private lateinit var accuracySpinner: Spinner
    private lateinit var status: TextView
    private lateinit var fileText: TextView
    private lateinit var liveText: TextView
    private lateinit var sessionName: EditText
    private lateinit var rootView: View
    private lateinit var pauseButton: Button
    private val uiHandler = Handler(Looper.getMainLooper())
    private val refreshRunnable = object : Runnable { override fun run() { refreshStatus(); uiHandler.postDelayed(this, 1000) } }

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val phone = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        if (fine && phone) startLogger() else status.text = "位置情報と電話の権限が必要です"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        rootView=findViewById(R.id.rootView); intervalSpinner=findViewById(R.id.intervalSpinner); gpsSpinner=findViewById(R.id.gpsSpinner); accuracySpinner=findViewById(R.id.accuracySpinner)
        status=findViewById(R.id.statusText); fileText=findViewById(R.id.fileText); liveText=findViewById(R.id.liveText); sessionName=findViewById(R.id.sessionName); pauseButton=findViewById(R.id.pauseButton)
        intervalSpinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("10秒","30秒","1分","2分","5分","10分")); intervalSpinner.setSelection(2)
        gpsSpinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("10秒","30秒","60秒（標準）","120秒")); gpsSpinner.setSelection(2)
        accuracySpinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf("高精度（目安 約5～20m）","標準（目安 約20～100m）","省電力（目安 約100m～数km）")); accuracySpinner.setSelection(0)
        findViewById<Button>(R.id.startButton).setOnClickListener { ensurePermissionsAndStart() }
        findViewById<Button>(R.id.stopButton).setOnClickListener { stopService(Intent(this,LoggingService::class.java)); getSharedPreferences("logger",MODE_PRIVATE).edit().putBoolean("running",false).putBoolean("paused",false).apply(); refreshStatus() }
        pauseButton.setOnClickListener { togglePause() }
        findViewById<Button>(R.id.shareButton).setOnClickListener { shareLatestCsv() }
        findViewById<Button>(R.id.historyButton).setOnClickListener { startActivity(Intent(this,HistoryActivity::class.java)) }
        findViewById<Button>(R.id.batteryButton).setOnClickListener { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_:Exception){ startActivity(Intent(Settings.ACTION_SETTINGS)) } }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.contentView)) { v, ins -> val b=ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()); v.setPadding(24.dp+b.left,24.dp+b.top,24.dp+b.right,32.dp+b.bottom); ins }
        refreshStatus()
    }
    private val Int.dp get()=(this*resources.displayMetrics.density).toInt()
    override fun onResume(){super.onResume();uiHandler.removeCallbacks(refreshRunnable);uiHandler.post(refreshRunnable)}
    override fun onPause(){uiHandler.removeCallbacks(refreshRunnable);super.onPause()}
    private fun ensurePermissionsAndStart(){ val ps=mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.READ_PHONE_STATE); if(Build.VERSION.SDK_INT>=33)ps+=Manifest.permission.POST_NOTIFICATIONS; val m=ps.filter{ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED};if(m.isEmpty())startLogger() else permissionLauncher.launch(m.toTypedArray()) }
    private fun startLogger(){
        val csvMs=listOf(10_000L,30_000L,60_000L,120_000L,300_000L,600_000L)[intervalSpinner.selectedItemPosition]
        val gpsMs=listOf(10_000L,30_000L,60_000L,120_000L)[gpsSpinner.selectedItemPosition]
        val priority=when(accuracySpinner.selectedItemPosition){0->Priority.PRIORITY_HIGH_ACCURACY;1->Priority.PRIORITY_BALANCED_POWER_ACCURACY;else->Priority.PRIORITY_LOW_POWER}
        val i=Intent(this,LoggingService::class.java).putExtra("intervalMs",csvMs).putExtra("locationIntervalMs",gpsMs).putExtra("locationPriority",priority).putExtra("sessionName",sessionName.text.toString())
        ContextCompat.startForegroundService(this,i)
    }
    private fun togglePause(){ val p=getSharedPreferences("logger",MODE_PRIVATE); if(!p.getBoolean("running",false))return; val paused=p.getBoolean("paused",false); val i=Intent(this,LoggingService::class.java).setAction(if(paused)"RESUME" else "PAUSE"); ContextCompat.startForegroundService(this,i) }
    private fun refreshStatus(){
        val p=getSharedPreferences("logger",MODE_PRIVATE); val running=p.getBoolean("running",false); val paused=p.getBoolean("paused",false); val rows=p.getLong("row_count",0)
        status.text=when{!running->"停止中";paused->"⏸ 記録一時停止中 / ${rows}行";else->"● 記録中 / ${rows}行"}; pauseButton.text=if(paused)"記録を再開" else "一時停止"; pauseButton.isEnabled=running
        rootView.setBackgroundColor(if(running&&!paused)Color.rgb(255,235,235) else Color.WHITE)
        val sims=(0..3).mapNotNull{p.getString("sim_$it",null)}
        liveText.text=if(sims.isEmpty())"SIM情報は記録開始後に表示されます" else sims.joinToString("\n\n"){formatSim(it)}
        val current=p.getString("current_file",null); val publicName=p.getString("public_file_name",null); fileText.text=if(current!=null)"保存先: Download/SignalLogger/${publicName?:File(current).name}" else "保存先: Download/SignalLogger/"
    }
    private fun formatSim(raw:String):String{ val a=raw.split('|'); if(a.size<6)return raw; val carrier=a[0];val svc=a[1];val net=a[2];val dbm=a[3];val roaming=a[4].toBoolean();val op=a[5]; val outage=a.getOrNull(6)?.toLongOrNull()?:0L; val dist=a.getOrNull(7).orEmpty(); val inSvc=svc=="IN_SERVICE"; val mark=if(inSvc)"🟢" else if(svc=="POWER_OFF")"⚪" else "🔴"; return buildString{append("$mark  $carrier\n");append(if(inSvc)"圏内" else if(svc=="POWER_OFF")"計測対象外" else "圏外");append("　$net　$dbm dBm"); if(!inSvc && outage>0){val sec=((System.currentTimeMillis()-outage)/1000).coerceAtLeast(0);append("\n圏外経過　${String.format("%02d:%02d",sec/60,sec%60)}");if(dist.isNotBlank())append("　最終圏内から ${dist} km")};if(roaming)append("\nローミング中　接続先：${op.ifBlank{"不明"}}")}}
    private fun shareLatestCsv(){ val p=getSharedPreferences("logger",MODE_PRIVATE);val source=p.getString("current_file",null)?.let{File(it)}?.takeIf{it.exists()}?:return;val d=File(cacheDir,"shared_csv").apply{mkdirs()};val snap=File(d,source.name);synchronized(LoggingService.FILE_LOCK){source.copyTo(snap,true)};val uri=androidx.core.content.FileProvider.getUriForFile(this,"$packageName.fileprovider",snap);startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="text/csv";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"CSVを共有・保存")) }
}
